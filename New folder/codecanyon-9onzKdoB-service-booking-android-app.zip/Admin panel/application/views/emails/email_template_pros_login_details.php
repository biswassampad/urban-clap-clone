<!DOCTYPE HTML>
<head>
	<meta http-equiv="content-type" content="text/html" />
	<meta name="author" content="lovely" />

	<title>Pros Login Details</title>
</head>

<body>
<p>Hi,
<br />
You are successfully registered as a Service Man, Please try following login details for your app
</p>
<p>
<strong>User Name : <?php echo $email; ?></strong>
<strong>Password : <?php echo $password; ?></strong>
</p>
</body>
</html>

