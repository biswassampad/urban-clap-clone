<p>Thank For Registration</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>Please confirm first your email id to success login.</p>
<p><?php echo site_url("login/confirm/?code=".$code."&email=".$email); ?></p>
<p>Copy past above link to your browser and confirm email.</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>Thanks</p>