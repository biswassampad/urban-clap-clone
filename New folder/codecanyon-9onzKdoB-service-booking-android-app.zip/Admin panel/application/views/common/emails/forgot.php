<p>Password Request</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>Please change your password.</p>
<p><?php echo site_url("login/reset?email=".$email."&access_token=".$code); ?></p>
<p>Copy past above link to your browser and reset password.</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>Thanks</p>